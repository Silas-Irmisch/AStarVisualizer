PROJECT: Visualizing A*  
by Silas Irmisch
