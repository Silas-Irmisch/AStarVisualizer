/** 	Vertex Class of Graphs
 *  	Purpose: bachelor thesis
 *  	Author: silas irmisch
 *  	Reference: ripphausen
 */

module.exports = class Vertex {
	// fields
	_id

	// @params: id as int
	constructor(id) {
		this._id = id
	}
}
